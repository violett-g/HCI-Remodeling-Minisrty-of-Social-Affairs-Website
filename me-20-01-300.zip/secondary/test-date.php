<?php
  session_start();
  require 'config.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Get table row data with javascript</title>
        <meta charset="utf-8" />
        <style>
            #container{
                margin:0 auto;
                width:80%;
                overflow:auto;
            }
            table.gridtable {
                margin:0 auto;
                width:95%;
                overflow:auto;
                font-family: helvetica,arial,sans-serif;
                font-size:14px;
                color:#333333;
                border-color: #666666;
                border-collapse: collapse;
                text-align: center;
            }
            table.gridtable th,td {
                padding: 8px;
                border-style: solid;
            }
            .headerrow {
                background-color: #F6B4A5;
            }
            .footerrow {
                background-color: #EEF8BF;
            }
            .datarow {
                background-color: whitesmoke;
            }			
        </style>
    </head>

    <body>
        <div class="container" id="container">
            <br><br><br><br><br><br>
            <table class="gridtable" id="tableMain">
                <thead>
                    <tr class="headerrow">
                        <th>column1</th>
                        <th>column2</th>
                        <th>column3</th>
                        <th>column4</th>
                        <th>column5</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="datarow">
                        <td><input value="a"/> Australia</td>
                        <td><input value="a"/>USA</td>
                        <td><input value="a"/>England</td>
                        <td><input value="a"/>France</td>
                        <td><input value="a"/>23.65</td>
                    </tr>
                    <tr class="datarow">
                        <td>Belgium</td>
                        <td>India</td>
                        <td>Switzerland</td>
                        <td>New Zealand</td>
                        <td>61.24</td>
                    </tr>
                    <tr class="datarow">
                        <td>South Korea</td>
                        <td>South Africa</td>
                        <td>Poland</td>
                        <td>Canada</td>
                        <td>11.05</td>
                    </tr>
                    <tr class="datarow">
                        <td>Russia</td>
                        <td>Senegal</td>
                        <td>Kenya</td>
                        <td>Argentina</td>
                        <td>35.24</td>
                    </tr>
                    <tr class="datarow">
                        <td>Portugal</td>
                        <td>Peru</td>
                        <td>Libya</td>
                        <td>China</td>
                        <td>21.47</td>
                    </tr>
                </tbody>
                <tfoot  class="footerrow">
                    <td>footer</td>
                    <td>footer</td>
                    <td>footer</td>
                    <td>footer</td>
                    <td>footer</td>
                 </tfoot>
            </table>
            <button id="button001"type="button">Go through all rows and cells</button><br>
            <button id="button002"type="button">Go through second column in each row</button><br>
			<button id="button003"type="button">Go through columns in first row</button><br>
			<button id="button004"type="button">Go through columns in last row</button><br>
			<button id="button005"type="button">Go through columns in third row</button><br>			
        </div>
		
		<script>
		
            document.getElementById("button001").addEventListener("click", function(){
				let thetable=document.getElementById("tableMain").getElementsByTagName('tbody')[0];
				for (let therow of thetable.rows) {
					let line="";
					for(let thecell of therow.cells) {
						line = line + thecell.value;					
					}
					alert(line);
				}
            });

            document.getElementById("button002").addEventListener("click", function(){
				let thetable=document.getElementById("tableMain").getElementsByTagName('tbody')[0];
                for (let therow of thetable.rows) {
                    alert(therow.cells[1].innerText);
                }
            });

            document.getElementById("button003").addEventListener("click", function(){ 
                let therow=document.getElementById("tableMain").getElementsByTagName('tbody')[0].rows[0];
                for(let thecell of therow.cells) {                               
                    alert(thecell.innerText);
                }
            });

            document.getElementById("button004").addEventListener("click", function(){ 
                let thetable=document.getElementById("tableMain").getElementsByTagName('tbody')[0];
                let therow =thetable.rows[thetable.rows.length - 1];
                for(let thecell of therow.cells) {                               
                    alert(thecell.innerText);
                }
            });		

            document.getElementById("button005").addEventListener("click", function(){ 
                let therow=document.getElementById("tableMain").getElementsByTagName('tbody')[0].rows[2];
                for(let thecell of therow.cells) {                               
                    alert(thecell.innerText);
                }
            });			
			
		</script>

	</body>
	</html>





